# Cricket-Prediction-
This is a predictive analysis project based on the sport - CRICKET where I would be looking into winning metrics of a game between 2 different teams playing the sport. This project was done using the Indian Premier League (IPL) 2023 data and with this we would be building models to fathom the factors required for a win and also seeing the players performances with different games. 



